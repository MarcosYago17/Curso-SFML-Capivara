#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>
#include <vector>
#include <sstream> // Para converter int para string e vice-versa

// =======================================================
// ESTADOS DA COMBOBOX
// =======================================================
enum ComboBoxState {
    CLOSED,
    OPEN
};

// =======================================================
// FUN��O PARA RODAR A JANELA DO FORMUL�RIO
// =======================================================
void runFormWindow() {
    sf::RenderWindow formWindow(sf::VideoMode(800, 900), "Formul�rio de Cadastro - SFML", sf::Style::Titlebar | sf::Style::Close);
    formWindow.setFramerateLimit(60);

    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) { // Verifique se arial.ttf est� dispon�vel
        std::cerr << "Erro ao carregar a fonte arial.ttf" << std::endl;
        return;
    }

    // =======================================================
    // ELEMENTOS DO FORMUL�RIO
    // =======================================================

    // --- T�tulo ---
    sf::Text title("Formul�rio de Cadastro", font, 40);
    title.setFillColor(sf::Color::Black);
    title.setPosition(150, 30);

    // --- Labels (R�tulos) ---
    sf::Text labelNome("Nome:", font, 24);
    labelNome.setFillColor(sf::Color::Black);
    labelNome.setPosition(50, 100);

    sf::Text labelIdade("Idade:", font, 24);
    labelIdade.setFillColor(sf::Color::Black);
    labelIdade.setPosition(50, 180);

    sf::Text labelNivelEstudo("N�vel de Estudo:", font, 24);
    labelNivelEstudo.setFillColor(sf::Color::Black);
    labelNivelEstudo.setPosition(50, 260);

    sf::Text labelSobreVoce("Sobre Voc�:", font, 24);
    labelSobreVoce.setFillColor(sf::Color::Black);
    labelSobreVoce.setPosition(50, 420);

    // --- Campos de Entrada de Texto (Nome e Idade) ---
    sf::RectangleShape inputRectNome(sf::Vector2f(400, 40));
    inputRectNome.setPosition(200, 100);
    inputRectNome.setFillColor(sf::Color(230, 230, 230));
    inputRectNome.setOutlineThickness(2);
    inputRectNome.setOutlineColor(sf::Color::Black);

    sf::RectangleShape inputRectIdade(sf::Vector2f(100, 40));
    inputRectIdade.setPosition(200, 180);
    inputRectIdade.setFillColor(sf::Color(230, 230, 230));
    inputRectIdade.setOutlineThickness(2);
    inputRectIdade.setOutlineColor(sf::Color::Black);

    // --- Campo "Sobre Voc�" (Multilinhas) ---
    sf::RectangleShape inputRectSobreVoce(sf::Vector2f(700, 150));
    inputRectSobreVoce.setPosition(50, 460);
    inputRectSobreVoce.setFillColor(sf::Color(230, 230, 230));
    inputRectSobreVoce.setOutlineThickness(2);
    inputRectSobreVoce.setOutlineColor(sf::Color::Black);

    // --- Textos de Entrada ---
    std::string textNomeStr = "";
    sf::Text textNome("", font, 20);
    textNome.setFillColor(sf::Color::Black);
    textNome.setPosition(inputRectNome.getPosition().x + 5, inputRectNome.getPosition().y + 5);

    std::string textIdadeStr = "";
    sf::Text textIdade("", font, 20);
    textIdade.setFillColor(sf::Color::Black);
    textIdade.setPosition(inputRectIdade.getPosition().x + 5, inputRectIdade.getPosition().y + 5);

    std::string textSobreVoceStr = "";
    sf::Text textSobreVoce("", font, 20);
    textSobreVoce.setFillColor(sf::Color::Black);
    textSobreVoce.setPosition(inputRectSobreVoce.getPosition().x + 5, inputRectSobreVoce.getPosition().y + 5);

    // --- Campo atualmente selecionado para digita��o ---
    sf::RectangleShape* activeInputRect = nullptr;
    std::string* activeInputString = nullptr;
    sf::Text* activeInputText = nullptr;

    // --- Combobox (Simulada) ---
    ComboBoxState comboBoxState = CLOSED;
    sf::RectangleShape comboBoxRect(sf::Vector2f(300, 40));
    comboBoxRect.setPosition(250, 260);
    comboBoxRect.setFillColor(sf::Color(230, 230, 230));
    comboBoxRect.setOutlineThickness(2);
    comboBoxRect.setOutlineColor(sf::Color::Black);

    sf::Text comboBoxSelectedText("Selecione um N�vel", font, 20);
    comboBoxSelectedText.setFillColor(sf::Color::Black);
    comboBoxSelectedText.setPosition(comboBoxRect.getPosition().x + 5, comboBoxRect.getPosition().y + 5);

    std::vector<std::string> studyLevels = {
        "Ensino Fundamental", "Ensino M�dio", "Gradua��o",
        "P�s-Gradua��o", "Mestrado", "Doutorado"
    };
    std::vector<sf::Text> comboBoxOptionsText;
    std::vector<sf::RectangleShape> comboBoxOptionsRect;
    float optionHeight = 35.0f;

    for (size_t i = 0; i < studyLevels.size(); ++i) {
        sf::RectangleShape optionRect(sf::Vector2f(300, optionHeight));
        optionRect.setPosition(comboBoxRect.getPosition().x, comboBoxRect.getPosition().y + (i + 1) * optionHeight);
        optionRect.setFillColor(sf::Color(200, 200, 200));
        optionRect.setOutlineThickness(1);
        optionRect.setOutlineColor(sf::Color::Black);
        comboBoxOptionsRect.push_back(optionRect);

        sf::Text optionText(studyLevels[i], font, 18);
        optionText.setFillColor(sf::Color::Black);
        optionText.setPosition(optionRect.getPosition().x + 5, optionRect.getPosition().y + 5);
        comboBoxOptionsText.push_back(optionText);
    }

    // --- Bot�o Enviar ---
    sf::RectangleShape submitButton(sf::Vector2f(150, 50));
    submitButton.setPosition(325, 700);
    submitButton.setFillColor(sf::Color(100, 200, 100)); // Verde
    submitButton.setOutlineThickness(2);
    submitButton.setOutlineColor(sf::Color::Black);

    sf::Text submitText("Enviar", font, 24);
    submitText.setFillColor(sf::Color::White);
    submitText.setPosition(submitButton.getPosition().x + (submitButton.getSize().x - submitText.getLocalBounds().width) / 2,
                           submitButton.getPosition().y + (submitButton.getSize().y - submitText.getLocalBounds().height) / 2 - 5);


    // =======================================================
    // LOOP PRINCIPAL DA JANELA DO FORMUL�RIO
    // =======================================================
    while (formWindow.isOpen()) {
        sf::Event event;
        while (formWindow.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                formWindow.close();
            }

            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2f mousePos = formWindow.mapPixelToCoords(sf::Mouse::getPosition(formWindow));

                // Clicou no campo Nome?
                if (inputRectNome.getGlobalBounds().contains(mousePos)) {
                    activeInputRect = &inputRectNome;
                    activeInputString = &textNomeStr;
                    activeInputText = &textNome;
                    inputRectNome.setOutlineColor(sf::Color::Blue);
                    inputRectIdade.setOutlineColor(sf::Color::Black);
                    inputRectSobreVoce.setOutlineColor(sf::Color::Black);
                    comboBoxRect.setOutlineColor(sf::Color::Black);
                }
                // Clicou no campo Idade?
                else if (inputRectIdade.getGlobalBounds().contains(mousePos)) {
                    activeInputRect = &inputRectIdade;
                    activeInputString = &textIdadeStr;
                    activeInputText = &textIdade;
                    inputRectNome.setOutlineColor(sf::Color::Black);
                    inputRectIdade.setOutlineColor(sf::Color::Blue);
                    inputRectSobreVoce.setOutlineColor(sf::Color::Black);
                    comboBoxRect.setOutlineColor(sf::Color::Black);
                }
                // Clicou no campo Sobre Voc�?
                else if (inputRectSobreVoce.getGlobalBounds().contains(mousePos)) {
                    activeInputRect = &inputRectSobreVoce;
                    activeInputString = &textSobreVoceStr;
                    activeInputText = &textSobreVoce;
                    inputRectNome.setOutlineColor(sf::Color::Black);
                    inputRectIdade.setOutlineColor(sf::Color::Black);
                    inputRectSobreVoce.setOutlineColor(sf::Color::Blue);
                    comboBoxRect.setOutlineColor(sf::Color::Black);
                }
                // Clicou no combobox?
                else if (comboBoxRect.getGlobalBounds().contains(mousePos)) {
                    comboBoxState = (comboBoxState == CLOSED) ? OPEN : CLOSED;
                    activeInputRect = nullptr; // Desativa digita��o
                    comboBoxRect.setOutlineColor(sf::Color::Blue);
                    inputRectNome.setOutlineColor(sf::Color::Black);
                    inputRectIdade.setOutlineColor(sf::Color::Black);
                    inputRectSobreVoce.setOutlineColor(sf::Color::Black);
                }
                // Clicou em uma op��o do combobox (se estiver aberto)?
                else if (comboBoxState == OPEN) {
                    for (size_t i = 0; i < comboBoxOptionsRect.size(); ++i) {
                        if (comboBoxOptionsRect[i].getGlobalBounds().contains(mousePos)) {
                            comboBoxSelectedText.setString(studyLevels[i]);
                            comboBoxState = CLOSED; // Fecha o combobox
                            comboBoxRect.setOutlineColor(sf::Color::Black);
                            break;
                        }
                    }
                }
                // Clicou no bot�o Enviar?
                else if (submitButton.getGlobalBounds().contains(mousePos)) {
                    std::cout << "--- Formul�rio Enviado ---" << std::endl;
                    std::cout << "Nome: " << textNomeStr << std::endl;
                    std::cout << "Idade: " << textIdadeStr << std::endl;
                    std::cout << "N�vel de Estudo: " << comboBoxSelectedText.getString().toAnsiString() << std::endl;
                    std::cout << "Sobre Voc�: " << textSobreVoceStr << std::endl;
                    std::cout << "--------------------------" << std::endl;
                    // Voc� pode adicionar aqui a l�gica para salvar os dados, etc.
                    // Por exemplo, fechar a janela: formWindow.close();
                }
                // Clicou fora de qualquer campo?
                else {
                    activeInputRect = nullptr;
                    activeInputString = nullptr;
                    activeInputText = nullptr;
                    inputRectNome.setOutlineColor(sf::Color::Black);
                    inputRectIdade.setOutlineColor(sf::Color::Black);
                    inputRectSobreVoce.setOutlineColor(sf::Color::Black);
                    comboBoxRect.setOutlineColor(sf::Color::Black);
                    comboBoxState = CLOSED; // Fecha combobox se clicou fora
                }
            }

            // Entrada de texto
            if (event.type == sf::Event::TextEntered && activeInputString != nullptr) {
                if (event.text.unicode == 8) { // Tecla Backspace
                    if (!activeInputString->empty()) {
                        activeInputString->pop_back();
                    }
                } else if (event.text.unicode < 128) { // Caracteres ASCII b�sicos
                    // L�gica para o campo de Idade: apenas n�meros
                    if (activeInputString == &textIdadeStr) {
                        if (event.text.unicode >= '0' && event.text.unicode <= '9') {
                            *activeInputString += static_cast<char>(event.text.unicode);
                        }
                    }
                    // L�gica para o campo "Sobre Voc�": permite novas linhas com Enter
                    else if (activeInputString == &textSobreVoceStr) {
                        if (event.text.unicode == '\r') { // Enter/Return
                            *activeInputString += '\n'; // Adiciona nova linha
                        } else {
                            *activeInputString += static_cast<char>(event.text.unicode);
                        }
                    }
                    // Outros campos de texto (Nome): todos os caracteres
                    else {
                        *activeInputString += static_cast<char>(event.text.unicode);
                    }
                }
                activeInputText->setString(*activeInputString);
            }
        }

        // =======================================================
        // DESENHO (RENDERIZA��O)
        // =======================================================
        formWindow.clear(sf::Color(173, 216, 230)); // Cor de fundo azul claro

        formWindow.draw(title);

        formWindow.draw(labelNome);
        formWindow.draw(inputRectNome);
        formWindow.draw(textNome);

        formWindow.draw(labelIdade);
        formWindow.draw(inputRectIdade);
        formWindow.draw(textIdade);

        formWindow.draw(labelNivelEstudo);
        formWindow.draw(comboBoxRect);
        formWindow.draw(comboBoxSelectedText);

        // Desenha as op��es do combobox se estiver aberto
        if (comboBoxState == OPEN) {
            for (size_t i = 0; i < comboBoxOptionsRect.size(); ++i) {
                formWindow.draw(comboBoxOptionsRect[i]);
                formWindow.draw(comboBoxOptionsText[i]);
            }
        }

        formWindow.draw(labelSobreVoce);
        formWindow.draw(inputRectSobreVoce);
        formWindow.draw(textSobreVoce); // O texto pode ser multilinhas

        formWindow.draw(submitButton);
        formWindow.draw(submitText);


        formWindow.display();
    }
}
int main() {
    runFormWindow();

    return 0;
}

